package com.example.metadata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetadataApplicationTests {

    @Test
    void contextLoads() {
    }

}
